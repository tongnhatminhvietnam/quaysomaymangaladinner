from django.db.models import QuerySet

query_set = QuerySet
query_obj = QuerySet
