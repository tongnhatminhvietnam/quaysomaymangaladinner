from django.contrib import admin
from .models import Verif, WhitelistTarget

admin.site.register(Verif)
admin.site.register(WhitelistTarget)
