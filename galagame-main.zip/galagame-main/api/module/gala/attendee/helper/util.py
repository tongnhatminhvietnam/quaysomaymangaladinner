from ..models import Attendee


class AttendeeUtil:
    @staticmethod
    def get_code_by_mobile(mobile: str) -> str:
        try:
            item = Attendee.objects.get(mobile=mobile)
            return item.code
        except Attendee.DoesNotExist:
            return ""
