from rest_framework.serializers import ModelSerializer, CharField
from rest_framework.validators import UniqueValidator
from ..models import Attendee


class AttendeeSr(ModelSerializer):
    class Meta:
        model = Attendee
        exclude = ()
        read_only_fields = ("id",)

    uid = CharField(
        validators=[
            UniqueValidator(
                queryset=Attendee.objects.all(),
                message="Duplicate attendee",
            )
        ]
    )
