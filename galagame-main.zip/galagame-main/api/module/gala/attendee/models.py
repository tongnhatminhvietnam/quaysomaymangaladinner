from django.db import models


class Attendee(models.Model):
    name = models.CharField(max_length=255)
    mobile = models.CharField(max_length=60, unique=True)
    code = models.CharField(max_length=60, unique=True)

    def __str__(self):
        return f"{self.name} -> {self.mobile}"

    class Meta:
        db_table = "attendees"
        ordering = ["-id"]
