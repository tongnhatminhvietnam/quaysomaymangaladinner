import os
from django.urls import path
from .views.custom import CheckView

app_name = os.getcwd().split(os.sep)[-1]
urlpatterns = [
    path("check/<str:mobile>", CheckView.as_view(), name="attendeeCheck"),
]
