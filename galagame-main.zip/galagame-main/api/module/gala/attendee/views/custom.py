from django.utils.translation import gettext_lazy as _
from rest_framework.views import APIView
from rest_framework.permissions import AllowAny
from service.request_service import RequestService
from module.gala.attendee.helper.util import AttendeeUtil


class CheckView(APIView):
    permission_classes = (AllowAny,)

    def get(self, request, mobile=None):
        code = AttendeeUtil.get_code_by_mobile(mobile)
        error_message = _("Bạn không có trong danh sách khách mời.")
        return (
            RequestService.res({"code": code})
            if code
            else RequestService.err({"detail": error_message})
        )
