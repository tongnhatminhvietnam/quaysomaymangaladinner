class SettingAttendees:
    MAX_OTP_PER_TARGET_PER_DAY = 10
