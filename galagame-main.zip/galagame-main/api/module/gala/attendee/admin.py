from django.contrib import admin
from .models import Attendee


class AttendeeAdmin(admin.ModelAdmin):
    list_display = (
        "name",
        "mobile",
        "code",
    )


admin.site.register(Attendee, AttendeeAdmin)
