from django.contrib import admin
from .models import Variable

admin.site.register(Variable)
