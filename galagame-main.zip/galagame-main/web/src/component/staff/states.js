import { atom } from "recoil";

export const staffOptionsSt = atom({
    key: "staffOptions",
    default: {}
});
