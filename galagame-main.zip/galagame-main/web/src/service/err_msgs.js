const ErrMsg = {
    REQUIRED: "Trường này là bắt buộc",
    GT_0: "Số này cần >= 0",
    INTEGER: "Trường này là số",
    EMAIL: "Email không hợp lệ",
    PHONE: "Số điện thoại không hợp lệ",
    RANGE: "Giá trị khởi đầu phải bé hơn giá trị kết thúc."
};
export default ErrMsg;
