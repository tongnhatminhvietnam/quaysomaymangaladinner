import { expect, describe, it } from "vitest";
describe("suite name", () => {
    it("Default test", () => {
        expect(true).to.be.true;
    });
});
